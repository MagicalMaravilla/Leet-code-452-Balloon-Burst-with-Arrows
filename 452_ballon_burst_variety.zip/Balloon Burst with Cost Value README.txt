Creating color coded value balloons:

Understanding: we use std:map which is a container that stores elements to combine key vvalues and mapped values, following a specific order. 
In my case, the key is string and the mapped value is the integer which is a monetary value.

Take Away: std::map automatically sorts its elements by the key values in ascending order. This property is useful for tasks that require data to be automatically organized.



Data association:

Concept: We associate two pieces of data (color, and value) allows me to create a mroe structured and meaningful representation of information.

Take Away: Understanding how we use link related information can help manage and utilize data more effectively in my program.


Looping Through Containers:

Using Range-based for Loops: In our example we demonstate iterating over a std::map using a range-based for loop. This is a concise and readable way to access all elements in a container.

Take Away: Get comfortable with different types of loops. Range-based loops are useful for iterating over elements in STL contains.



Importance of Types:

Strings and Integers: Our example uses strings to represent balloon colors and integers for their values. Showing hwo to combine different types can model a real life scenario.

Take Away: learning how and when to use various data types is fundamental. It enables me to model diverse kinds of information in your programs accurately.



values based on rainbow sequence and corresponding values


Violet (inside)
Indigo
Blue
Green
Yellow
Orange
Red (outside)


Violet: $25 (since it's the innermost color, it gets the lowest value)
Indigo: $50 
Blue: $75
Green: $100
Yellow: $150
Orange: $175 
Red: $200



How we sorted out the balloons:

Concept: std::map and std::vector<std::pair<std::string, int>> are examples of containers from the Standard Template Library (STL). A pair is a simple container consisting of two elements

Take Away: Understanding different types of containers and when to use them is important, std::map is great for key value associations, while std::vector is a dynamic array that can be sorted and iterated over easily.


Lambda Expressions:

Concept: The code uses a lambda expression as a custom comparator for sorting. Lambda expressiong allow me to define anonymous functions directly where they are used.

Take Away: Lambdras are powerful and concise code and are useful for defning behavior inline, like custom sorting criteria. They enhance readability and flexability.


Sorting with Customer Comparator:

Concept: The std::sort function is used with a lambda expression to sort the vector of pairs by their second element (monetary value) in decending order.

Take Away: Learning how to sort data based on custom criteria is essential in programming tasks. Custom comparators provide the flexabilityto sort data in ways that aren't supported by default



Transfer of Data Between Containers:

Concept: The example I have demonstates transferring data from a std::map to a std:: vector of pairs. 
This techniquie is useful when the sorting or manipulation requirements cannot be easily met by the original container.

Take Away: Sometimes, no single container fulfuills all requirements, and transferring data between containers can be a practical solution. 
Understanding the characteristic of different containers allows me to choose the right one for my needs