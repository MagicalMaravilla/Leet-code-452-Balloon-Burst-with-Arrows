#include <iostream>
#include <vector>
#include <algorithm>
#include <random>
#include <unordered_set>
#include <cassert>

// Balloon struct representing each balloon in the simulation.
struct Balloon {
    std::string color; // Visual identifier for the balloon.
    int value;         // Numeric value associated with popping this balloon.
    int start;         // Starting position on an imaginary horizontal line.
    int end;           // Ending position, defining the balloon's occupied space.
    int clusterId;     // Identifier for the cluster this balloon is part of.

    // Constructor for initializing balloon properties.
    Balloon(std::string col, int val, int s, int e, int cid)
        : color(std::move(col)), value(val), start(s), end(e), clusterId(cid) {}
};

// Function to generate a random number within a specified range.
int getRandomNumber(int min, int max) {
    static std::random_device rd; // Seed with a real random value, if available.
    static std::mt19937 eng(rd()); // Standard mersenne_twister_engine seeded with rd().
    std::uniform_int_distribution<> distr(min, max); // Define the range.
    return distr(eng); // Generate and return a random number within the range.
}

// Function with improved error checking for random number generation.
int safeGetRandomNumber(int min, int max) {
    if (min > max) {
        std::cerr << "Invalid range for random number generation: min > max.\n";
        return min; // Return min to prevent crashing, indicating an error.
    }
    return getRandomNumber(min, max);
}

// Function to generate balloons with initial positions and randomly assign them to clusters.
std::vector<Balloon> generateBalloonsWithClusters(const std::vector<std::pair<std::string, int>>& balloonTemplates, int clusterCount) {
    if (clusterCount < 1) {
        std::cerr << "Cluster count must be at least 1.\n";
        return {}; // Return an empty vector as a failure indication.
    }

    std::vector<Balloon> balloons;
    for (const auto& templateBalloon : balloonTemplates) {
        int start = safeGetRandomNumber(1, 100); // Ensure start position is within bounds.
        int end = safeGetRandomNumber(start + 1, std::min(start + 50, 100)); // Ensure end is within bounds and follows start.
        int clusterId = safeGetRandomNumber(1, clusterCount); // Randomly assign a cluster ID.
        balloons.emplace_back(templateBalloon.first, templateBalloon.second, start, end, clusterId);
    }
    return balloons; // Return the vector of generated balloons.
}

// Function to dynamically form clusters based on the current positions of balloons.
std::vector<Balloon> generateAdaptiveClusters(std::vector<Balloon>& balloons, int maxClusterSize) {
    if (maxClusterSize < 1) {
        std::cerr << "Maximum cluster size must be at least 1.\n";
        return balloons; // Return the original vector without modification as an error indication.
    }

    std::sort(balloons.begin(), balloons.end(), [](const Balloon& a, const Balloon& b) {
        return a.start < b.start; // Sort balloons by their start position to group by proximity.
    });

    int currentClusterId = 1; // Start with the first cluster.
    int balloonsInCurrentCluster = 0; // Track the number of balloons in the current cluster.
    int lastEndPosition = 0; // Remember the end position of the last balloon in a cluster.

    for (auto& balloon : balloons) {
        // Start a new cluster if the maximum size is reached or balloons are too far apart.
        if (balloonsInCurrentCluster >= maxClusterSize || (balloon.start - lastEndPosition > 10 && balloonsInCurrentCluster > 0)) {
            currentClusterId++; // Move to the next cluster.
            balloonsInCurrentCluster = 0; // Reset the balloon count for the new cluster.
        }
        balloon.clusterId = currentClusterId; // Assign the current cluster ID to this balloon.
        balloonsInCurrentCluster++; // Increment the count of balloons in the current cluster.
        lastEndPosition = balloon.end; // Update the last end position for proximity checking.
    }
    return balloons; // Return the vector with updated cluster assignments.
}

// Function to simulate the movement of balloons, introducing randomness in direction and distance.
void moveBalloons(std::vector<Balloon>& balloons) {
    for (auto& balloon : balloons) {
        int moveVariability = safeGetRandomNumber(-5, 5); // Randomly determines the distance of movement.
        bool moveRight = safeGetRandomNumber(0, 1) == 1; // Randomly determines the direction of movement.

        if (moveRight) {
            balloon.start += moveVariability;
            balloon.end += moveVariability;
        } else {
            balloon.start -= moveVariability;
            balloon.end -= moveVariability;
        }

        // Ensures that the balloon's position remains within the simulation's boundaries.
        balloon.start = std::max(1, std::min(balloon.start, 100));
        balloon.end = std::max(1, std::min(balloon.end, 100));
    }
}

// Calculates the minimum number of arrows required to burst all balloons and the total value gained.
int findMinArrowShotsAndCalculateValue(std::vector<Balloon>& balloons, int& totalValue) {
    totalValue = 0; // Resets total value for this calculation.
    if (balloons.empty()) return 0; // No balloons, no arrows needed.

    // Ensure balloons are clustered considering their current positions.
    auto clusteredBalloons = generateAdaptiveClusters(balloons, 3);

    // Sorts balloons by their end position to optimize arrow usage.
    std::sort(clusteredBalloons.begin(), clusteredBalloons.end(), [](const Balloon& a, const Balloon& b) {
        return a.end < b.end;
    });

    std::unordered_set<int> poppedClusters; // Tracks clusters that have been hit by an arrow.
    int arrowCount = 0;

    for (const auto& balloon : clusteredBalloons) {
        if (poppedClusters.find(balloon.clusterId) == poppedClusters.end()) {
            poppedClusters.insert(balloon.clusterId); // Marks the cluster as hit.
            arrowCount++; // An arrow is used for the cluster.
            // Adds up the values of all balloons in the hit cluster.
            totalValue += balloon.value;
        }
    }

    return arrowCount; // Returns the total number of arrows used.
}

void testGetRandomNumber() {
    // Testing if getRandomNumber returns a number within the specified range.
    int number = getRandomNumber(1, 10);
    assert(number >= 1 && number <= 10);
    std::cout << "testGetRandomNumber passed.\n";
}

void testGenerateBalloonsWithClusters() {
    // Ensure balloons are generated with expected properties.
    std::vector<std::pair<std::string, int>> templates = {{"Test", 100}};
    auto balloons = generateBalloonsWithClusters(templates, 1);
    assert(balloons.size() == 1 && balloons[0].value == 100);
    std::cout << "testGenerateBalloonsWithClusters passed.\n";
}

void testGenerateAdaptiveClusters() {
    // Test adaptive clustering by generating balloons close in position, expecting them to be in the same cluster.
    std::vector<Balloon> balloons = {{ "Red", 200, 1, 2, 1}, {"Blue", 150, 3, 4, 1}};
    auto clusteredBalloons = generateAdaptiveClusters(balloons, 2);
    assert(clusteredBalloons[0].clusterId == clusteredBalloons[1].clusterId);
    std::cout << "testGenerateAdaptiveClusters passed.\n";
}

void testMoveBalloons() {
    // Ensure balloons move within the expected boundaries.
    std::vector<Balloon> balloons = {{ "Green", 100, 50, 51, 1}};
    moveBalloons(balloons);
    assert(balloons[0].start >= 1 && balloons[0].end <= 100);
    std::cout << "testMoveBalloons passed.\n";
}

void testFindMinArrowShotsAndCalculateValue() {
    // Test calculation with a simple scenario.
    std::vector<Balloon> balloons = {{ "Yellow", 50, 1, 2, 1}};
    int totalValue = 0;
    int arrowsNeeded = findMinArrowShotsAndCalculateValue(balloons, totalValue);
    assert(arrowsNeeded == 1 && totalValue == 50);
    std::cout << "testFindMinArrowShotsAndCalculateValue passed.\n";
}

int main() {
    std::cout << "Starting test cases...\n";
    
    testGetRandomNumber();
    testGenerateBalloonsWithClusters();
    testGenerateAdaptiveClusters();
    testMoveBalloons();
    testFindMinArrowShotsAndCalculateValue();
    
    std::cout << "All test cases passed!\n";
        // After testing, proceed with the actual balloon burst simulation.
    std::cout << "\nProceeding with the actual Balloon Burst Simulation...\n";

    // Re-define balloon templates with a broader range of colors and values for the actual simulation.
std::vector<std::pair<std::string, int>> balloonTemplatesForSimulation = {
    {"Red", 200}, {"Blue", 150}, {"Green", 100}, {"Yellow", 50},
    {"Purple", 180}, {"Orange", 160}, {"Teal", 140}, {"Pink", 130},
    {"Cyan", 120}, {"Magenta", 110}, {"Lime", 90}, {"Maroon", 80},
    {"Olive", 70}, {"Navy", 60}, {"Grey", 55}, {"Violet", 45},
    {"Turquoise", 175}, {"Tan", 165}, {"Salmon", 135}, {"Plum", 125},
    {"Beige", 95}, {"Lavender", 85}, {"Mint", 75}, {"Coral", 65}
};

   // Generate balloons with clusters for the simulation.
auto simulationBalloons = generateBalloonsWithClusters(balloonTemplatesForSimulation, 3); // Limited number of clusters

// Dynamically cluster the simulation balloons based on their current positions.
simulationBalloons = generateAdaptiveClusters(simulationBalloons, 2); // Restricting clusters to have a maximum size


    // Simulate balloon movement for the actual run.
    moveBalloons(simulationBalloons);

    // Calculate and display the results of the simulation.
    int simulationTotalValue = 0;
    int simulationArrowsNeeded = findMinArrowShotsAndCalculateValue(simulationBalloons, simulationTotalValue);

    std::cout << "For the simulation:\n";
    std::cout << "Total arrows needed: " << simulationArrowsNeeded << "\n";
    std::cout << "Total value gained from popped balloons: " << simulationTotalValue << "\n";

    return 0;
}
